Weathering — Full React (Vite) project
-------------------------------------
- Push this repo to GitHub and import to Vercel.
- On Vercel, set environment variables if you have:
  - OWM_KEY (OpenWeatherMap API key)
  - OPENAI_KEY (for AI assistant)
- Vercel will run `npm install` and `npm run build` in the client folder.
